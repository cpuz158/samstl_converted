#include <iostream>
#include <list>
#include <algorithm>

int main()
{
	std::list<int> s = { 1,2,3,4,5,6,7,3,9,10 };

	std::list<int>::iterator p1 = s.begin(); // begin(s);
}
