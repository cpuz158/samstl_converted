#include <iostream>

class Point
{
	int x, y;
public:
	Point(int a, int b) : x(a), y(b) {}
};
int main()
{
	Point p1(1, 2);
	Point p2(1, 2);

	if (p1 == p2)
	{
	}
}


