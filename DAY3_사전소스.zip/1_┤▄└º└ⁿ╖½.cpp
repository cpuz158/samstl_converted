template<typename T> class List
{	
public:
	void push_front(const T& a)
	{
	}
};
List<int> st;

int main()
{
	st.push_front(10);
}